﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MobiTrain
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        public static string InputBox(string prompt, string title, string defaultValue)
        {
            InputBoxDialog ib = new InputBoxDialog();
            ib.FormPrompt = prompt;
            ib.FormCaption = title;
            ib.DefaultValue = defaultValue;
            ib.ShowDialog();
            string s = ib.InputResponse;
            ib.Close();
            return s;
        }

        private void btnAddTrainer_Click(object sender, EventArgs e)
        {
            int intArrayCount;
            string strTrainerName;
            double dblChargeRate;
            string[] NameArray = new string[3];
            double[] RateArray = new double[3];
            for (intArrayCount = 0; intArrayCount < NameArray.Length; ++intArrayCount)
            {
                strTrainerName = InputBox("Enter Name of Trainer", "Add Trainer", "");
                dblChargeRate = Convert.ToDouble(InputBox("Enter Charge Rate", "Charge rate", ""));
                NameArray[intArrayCount] = strTrainerName;
                RateArray[intArrayCount] = dblChargeRate;
            }
            ArrayClass.Name = NameArray;
            ArrayClass.Rate = RateArray;
        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Login f2 = new Login();
            this.Visible = false;
            f2.ShowDialog();

        }
    }
}
