﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MobiTrain
{
    public partial class Client : Form
    {

        public Client()
        {
            InitializeComponent();
        }
        //OTHER LOCATIONS
        double dblNotGym = 200;
        //EXTRAS
        double dblBodAss = 250;
        double dblNutGui = 250;
        double dblExePla = 300;

        
        private void Client_Load(object sender, EventArgs e)
        {
            int ArrayCount;
            string[] NameArray = ArrayClass.Name;
            double[] RateArray = ArrayClass.Rate;
            for (ArrayCount = 0; ArrayCount < ArrayClass.Name.Length; ++ArrayCount)
                cboTrainerName.Items.Add(NameArray[ArrayCount]);



        }
        private bool ValidateHours(bool blnValidHrs)
        {
            double dblhrs = Convert.ToDouble(nuUpDowHrs.Text);
            if (radButGym.Checked == true)
            {
                if (dblhrs != 0.5)
                {
                    blnValidHrs = false;
                    MessageBox.Show("client can only book for 30 minutes if training at the gym");

                }
            }
            else if (dblhrs >= 1)
            {
                if (dblhrs % 0.5 != 0)
                {
                    blnValidHrs = false;
                    MessageBox.Show("Invalid hours ,the hours must be in increments of 30 minutes");


                }
            }
            else
            {
                blnValidHrs = false;
                MessageBox.Show("Invalida Hours , Selected hours are too low");

            }
            return blnValidHrs;
        }
        private bool ValidLocation(bool blnValidLocation)
        {
            if (radButGym.Checked == false)
            {
                if (radButHome.Checked == false)
                {
                    if (radButOffice.Checked == false)
                    {
                        if (radButSchool.Checked == false)
                        {
                            blnValidLocation = false;
                            MessageBox.Show("Please select a place you would like to train");
                        }
                    }
                }
            }
            return blnValidLocation;
        }
        //this method validates the date
        private bool ValidateDate(bool blnValidDate)
        {
            
            if (dateTimePicker1.Value <= DateTime.Now.AddDays(1))
            {
                blnValidDate = false;
                MessageBox.Show("Book at least 2 days in advance");
            }
            return blnValidDate;
        }
        private double ProcessAmt(ref double dblCharges, ref double dblXtras)
        {
            

            double[] ChargeRateArray = ArrayClass.Rate;


            double dblHrs = Convert.ToDouble(nuUpDowHrs.Text);
            double dblRate = Convert.ToDouble(ChargeRateArray[cboTrainerName.SelectedIndex]);
            //CALCULATE CHARGES
            dblCharges = dblRate * dblHrs;



            //when location is not gyme
            if (radButGym.Checked != true)
            {
                dblCharges += dblNotGym;
            }
            //Work out Extras
            if (cheBoxBodAss.Checked == true)
            {
                dblCharges += dblBodAss;
                dblXtras += dblBodAss;
            }
            if (cheBoxExePla.Checked == true)
            {
                dblCharges += dblExePla;
                dblXtras += dblExePla;
            }
            if (cheBoxNutGui.Checked == true)
            {
                dblCharges += dblNutGui;
                dblXtras += dblNutGui;
            }




            return dblCharges;
        }
        private void DisplayOut(double dblCharges, double dblXtras)
        {
            String strLocation = "";
            if (radButGym.Checked == true)
            {
                strLocation = "Gym";
            }
            if (radButHome.Checked == true)
            {
                strLocation = "Home";
            }
            if (radButOffice.Checked == true)
            {
                strLocation = "Office";
            }
            if (radButSchool.Checked == true)
            {
                strLocation = "School";

            }

            lblConMsg1.Text =  "You are booked to train on " + dateTimePicker1.Text + " for " + Convert.ToString(nuUpDowHrs.Value) + " hour(s)" + " at " + strLocation + " with " + cboTrainerName.SelectedItem;

            lblConMsg2.Text = "The training session will cost " + dblCharges.ToString("C") + " and extras will cost " + dblXtras.ToString("C");

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            nuUpDowHrs.Text = "";
            cboTrainerName.Text = "";
            lblConMsg1.Text = "";
            lblConMsg2.Text = "";
            cheBoxBodAss.Checked = false;
            cheBoxExePla.Checked = false;
            cheBoxNutGui.Checked = false;
            radButGym.Checked = false;
            radButHome.Checked = false;
            radButOffice.Checked = false;
            radButSchool.Checked = false;
            dateTimePicker1.Value = DateTime.Now;
            cboTrainerName.Focus();



        }

        private void btnProcess_Click(object sender, EventArgs e)
        {

            double dblCharges = 0;
            double dblXra = 0;
            bool blnValidLocation = true;
            bool blnValidHrs = true;
            bool blnValidDate = true;

            blnValidDate = ValidateDate(blnValidDate);
            blnValidLocation = ValidLocation(blnValidLocation);
            blnValidHrs = ValidateHours(blnValidHrs);
            if(blnValidDate && blnValidHrs && blnValidHrs)
            {
                ProcessAmt(ref dblCharges, ref dblXra);
                DisplayOut(dblCharges, dblXra);


            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Login f4 = new Login();
            this.Visible = false;
            f4.ShowDialog();
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
    }
}
