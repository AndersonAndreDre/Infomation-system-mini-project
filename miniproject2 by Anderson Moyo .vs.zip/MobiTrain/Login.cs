﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobiTrain
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        int incorrPass;
        public static string InputBox(string prompt, string title, string defaultValue)
        {
            InputBoxDialog ib = new InputBoxDialog();
            ib.FormPrompt = prompt;
            ib.FormCaption = title;
            ib.DefaultValue = defaultValue;
            ib.ShowDialog();
            string s = ib.InputResponse;
            ib.Close();
            return s;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPassword.Text = "";
            cBoxLogin.Text = "";
            cBoxLogin.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {


            //THESE ARE MYPASSWORDS
            string strAdminPass = "A1632";
            string strClientPass = "C1632";

            //Validating Admin Passord
            incorrPass = incorrPass + 1;
            if (cBoxLogin.Text == "Admin")
            {


                if (txtPassword.Text == strAdminPass)
                {

                    Admin f2 = new Admin();
                    this.Visible = false;
                    f2.ShowDialog();
                }

                else
                {
                    MessageBox.Show("Password or Login incorrect");

                    if (incorrPass < 3)
                    {

                        txtPassword.Focus();
                    }
                    else
                    {


                        Application.Exit();
                    }


                }
            }


            //Validating Client Password
            else if (cBoxLogin.Text == "Client")
            {




                if (txtPassword.Text == strClientPass)
                {

                    Client f1 = new Client();
                    this.Visible = false;
                    f1.ShowDialog();
                }

                else
                {
                    MessageBox.Show("Password or Login incorrect");

                    if (incorrPass < 3)
                    {

                        txtPassword.Focus();
                    }
                    else
                    {


                        Application.Exit();
                    }


                }
            }

        }


















    }

}




