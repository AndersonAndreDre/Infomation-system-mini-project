﻿
namespace MobiTrain
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cboTrainerName = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.nuUpDowHrs = new System.Windows.Forms.NumericUpDown();
            this.btnProcess = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radButOffice = new System.Windows.Forms.RadioButton();
            this.radButGym = new System.Windows.Forms.RadioButton();
            this.radButSchool = new System.Windows.Forms.RadioButton();
            this.radButHome = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cheBoxExePla = new System.Windows.Forms.CheckBox();
            this.cheBoxNutGui = new System.Windows.Forms.CheckBox();
            this.cheBoxBodAss = new System.Windows.Forms.CheckBox();
            this.lblConMsg1 = new System.Windows.Forms.Label();
            this.lblConMsg2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nuUpDowHrs)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(235, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(323, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "BOOKING A PERSONAL TRAINER";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select trainer";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Select hours";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Select date";
            // 
            // cboTrainerName
            // 
            this.cboTrainerName.FormattingEnabled = true;
            this.cboTrainerName.Location = new System.Drawing.Point(279, 85);
            this.cboTrainerName.Name = "cboTrainerName";
            this.cboTrainerName.Size = new System.Drawing.Size(138, 23);
            this.cboTrainerName.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dddd dd MMM";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(279, 157);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(138, 23);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // nuUpDowHrs
            // 
            this.nuUpDowHrs.DecimalPlaces = 1;
            this.nuUpDowHrs.Location = new System.Drawing.Point(279, 241);
            this.nuUpDowHrs.Name = "nuUpDowHrs";
            this.nuUpDowHrs.Size = new System.Drawing.Size(138, 23);
            this.nuUpDowHrs.TabIndex = 6;
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(0, 389);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(111, 32);
            this.btnProcess.TabIndex = 18;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(314, 389);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(92, 32);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(548, 389);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(102, 34);
            this.btnReturn.TabIndex = 20;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radButOffice);
            this.groupBox1.Controls.Add(this.radButGym);
            this.groupBox1.Controls.Add(this.radButSchool);
            this.groupBox1.Controls.Add(this.radButHome);
            this.groupBox1.Location = new System.Drawing.Point(516, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(154, 166);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Where do you want to train?";
            this.toolTip1.SetToolTip(this.groupBox1, "Select a place you want to train at");
            // 
            // radButOffice
            // 
            this.radButOffice.AutoSize = true;
            this.radButOffice.Location = new System.Drawing.Point(0, 147);
            this.radButOffice.Name = "radButOffice";
            this.radButOffice.Size = new System.Drawing.Size(90, 19);
            this.radButOffice.TabIndex = 11;
            this.radButOffice.TabStop = true;
            this.radButOffice.Text = "At the office";
            this.radButOffice.UseVisualStyleBackColor = true;
            // 
            // radButGym
            // 
            this.radButGym.AutoSize = true;
            this.radButGym.Location = new System.Drawing.Point(0, 109);
            this.radButGym.Name = "radButGym";
            this.radButGym.Size = new System.Drawing.Size(84, 19);
            this.radButGym.TabIndex = 10;
            this.radButGym.TabStop = true;
            this.radButGym.Text = "At the gym";
            this.radButGym.UseVisualStyleBackColor = true;
            // 
            // radButSchool
            // 
            this.radButSchool.AutoSize = true;
            this.radButSchool.Location = new System.Drawing.Point(0, 72);
            this.radButSchool.Name = "radButSchool";
            this.radButSchool.Size = new System.Drawing.Size(76, 19);
            this.radButSchool.TabIndex = 9;
            this.radButSchool.TabStop = true;
            this.radButSchool.Text = "At School";
            this.radButSchool.UseVisualStyleBackColor = true;
            // 
            // radButHome
            // 
            this.radButHome.AutoSize = true;
            this.radButHome.Location = new System.Drawing.Point(0, 47);
            this.radButHome.Name = "radButHome";
            this.radButHome.Size = new System.Drawing.Size(71, 19);
            this.radButHome.TabIndex = 8;
            this.radButHome.TabStop = true;
            this.radButHome.Text = "At home";
            this.radButHome.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cheBoxExePla);
            this.groupBox2.Controls.Add(this.cheBoxNutGui);
            this.groupBox2.Controls.Add(this.cheBoxBodAss);
            this.groupBox2.Location = new System.Drawing.Point(720, 80);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(229, 194);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Any extras required?";
            this.toolTip2.SetToolTip(this.groupBox2, "Do you requireany extra service(s)");
            // 
            // cheBoxExePla
            // 
            this.cheBoxExePla.AutoSize = true;
            this.cheBoxExePla.Location = new System.Drawing.Point(13, 139);
            this.cheBoxExePla.Name = "cheBoxExePla";
            this.cheBoxExePla.Size = new System.Drawing.Size(94, 19);
            this.cheBoxExePla.TabIndex = 15;
            this.cheBoxExePla.Text = "Exercise plan";
            this.cheBoxExePla.UseVisualStyleBackColor = true;
            // 
            // cheBoxNutGui
            // 
            this.cheBoxNutGui.AutoSize = true;
            this.cheBoxNutGui.Location = new System.Drawing.Point(13, 82);
            this.cheBoxNutGui.Name = "cheBoxNutGui";
            this.cheBoxNutGui.Size = new System.Drawing.Size(136, 19);
            this.cheBoxNutGui.TabIndex = 14;
            this.cheBoxNutGui.Text = "Nutritional Guideline";
            this.cheBoxNutGui.UseVisualStyleBackColor = true;
            // 
            // cheBoxBodAss
            // 
            this.cheBoxBodAss.AutoSize = true;
            this.cheBoxBodAss.Location = new System.Drawing.Point(13, 36);
            this.cheBoxBodAss.Name = "cheBoxBodAss";
            this.cheBoxBodAss.Size = new System.Drawing.Size(116, 19);
            this.cheBoxBodAss.TabIndex = 13;
            this.cheBoxBodAss.Text = "Body assessment";
            this.cheBoxBodAss.UseVisualStyleBackColor = true;
            // 
            // lblConMsg1
            // 
            this.lblConMsg1.AutoSize = true;
            this.lblConMsg1.Location = new System.Drawing.Point(0, 295);
            this.lblConMsg1.Name = "lblConMsg1";
            this.lblConMsg1.Size = new System.Drawing.Size(166, 15);
            this.lblConMsg1.TabIndex = 16;
            this.lblConMsg1.Text = "Confirmation message - line 1";
            // 
            // lblConMsg2
            // 
            this.lblConMsg2.AutoSize = true;
            this.lblConMsg2.Location = new System.Drawing.Point(0, 346);
            this.lblConMsg2.Name = "lblConMsg2";
            this.lblConMsg2.Size = new System.Drawing.Size(166, 15);
            this.lblConMsg2.TabIndex = 17;
            this.lblConMsg2.Text = "Confirmation message - line 2";
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(928, 450);
            this.Controls.Add(this.lblConMsg2);
            this.Controls.Add(this.lblConMsg1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.nuUpDowHrs);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.cboTrainerName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Client";
            this.Text = "Confirmation message - line 2";
            this.Load += new System.EventHandler(this.Client_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nuUpDowHrs)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboTrainerName;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.NumericUpDown nuUpDowHrs;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radButOffice;
        private System.Windows.Forms.RadioButton radButGym;
        private System.Windows.Forms.RadioButton radButSchool;
        private System.Windows.Forms.RadioButton radButHome;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cheBoxExePla;
        private System.Windows.Forms.CheckBox cheBoxNutGui;
        private System.Windows.Forms.CheckBox cheBoxBodAss;
        private System.Windows.Forms.Label lblConMsg1;
        private System.Windows.Forms.Label lblConMsg2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
    }
}