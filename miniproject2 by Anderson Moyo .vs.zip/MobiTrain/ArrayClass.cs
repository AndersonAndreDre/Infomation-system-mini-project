﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobiTrain
{
    class ArrayClass
    {
        public static string[] Name = new string[3];
        public static double[] Rate = new double[3];
    }
}
